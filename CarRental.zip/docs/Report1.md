# Report #1 - Car Rental Application

## 1. Team Members
- Student 1: ____________________
- Student 2: ____________________
- Student 3: ____________________

## 2. Program Description
This project implements a secure car rental application that helps the user choose the most suitable rental car based on:
- number of passengers,
- number of rental days,
- expected travel mileage.

The application stores a set of cars from the required vehicle categories and groups them into the rental hierarchy specified in the project description:
- Economy
- Intermediate
- Standard
- Van

For each available car, the system calculates:
- rental cost based on the daily rental rate,
- fuel cost based on gas price ($2.25 per gallon) and the car MPG,
- total trip cost.

The final recommendation is made by selecting the cheapest valid car first. If multiple cars have the same total cost, the application uses comfort level as the tie-breaker. The user can then see the make and model, supported passenger capacity, and total trip cost.

## 3. Security Principles Used
1. Encapsulation
2. Input Validation
3. Fail Securely

## 4. Why These Security Principles Were Used
### 4.1 Encapsulation
Encapsulation is used by making object fields private and exposing access through controlled getters. This reduces the chance of accidental or unauthorized modification of important data such as car details, rental category, and mileage values.

Why needed in this application:
- protects the integrity of car and quote data,
- prevents direct manipulation of sensitive calculation inputs,
- makes the program easier to control and audit.

### 4.2 Input Validation
Input validation is used throughout constructors and calculation methods. The program checks for invalid values such as:
- empty make or model,
- null vehicle type or category,
- non-positive MPG,
- invalid passenger count,
- invalid rental days,
- negative trip distance.

The program also validates that the selected rental category matches the allowed vehicle type hierarchy from the project specification.

Why needed in this application:
- prevents invalid or malicious input from corrupting calculations,
- ensures business rules are enforced correctly,
- reduces the risk of runtime failures and unexpected behavior.

### 4.3 Fail Securely
The application handles invalid inputs and unexpected conditions using exceptions and safe error messages instead of continuing with corrupted state.

Why needed in this application:
- prevents the system from producing misleading rental recommendations,
- stops execution safely when invalid data is detected,
- improves reliability and reduces misuse of the application.

## 5. Security Requirements
The following security requirements were identified for the application:

1. The system shall validate all user inputs before performing any rental or fuel cost calculation.
2. The system shall reject invalid car definitions such as null values, empty names, negative values, or unsupported category-to-vehicle mappings.
3. The system shall prevent negative or zero values for rental days, passenger count, and MPG where such values would make the calculation invalid.
4. The system shall handle invalid input and internal errors gracefully without crashing or exposing internal program state.
5. The system shall maintain data integrity by restricting direct modification of core object attributes.

## 6. Screenshots From the Program
Insert screenshots of the following:

1. The application startup screen showing the available cars.
2. A valid execution example with user input and the recommended result.
3. An invalid input example showing secure error handling.

Suggested captions:
- Figure 1: Available cars displayed by the application.
- Figure 2: Valid rental recommendation result.
- Figure 3: Invalid input handled safely.

## Notes
Items not required in Report #1 for Part I:
- JUnit testing
- Fuzz testing
- Coverage report
- Defect reports

These belong to the individual testing stage in Part II.
